const mongoose = require('mongoose');

const EventSchema = mongoose.Schema({
    id: Number,
    name: String,
    department: String,
    date: String,
    invited: Number,
    accepted: Number
}, {
    timestamps: true
});

module.exports = mongoose.model('Events', EventSchema);